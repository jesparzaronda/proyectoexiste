<?php
/*
 * Gallery display
 *
 * @package classes\structure
 */

namespace tm_photo_gallery\classes\structure;

use tm_photo_gallery\classes\Structure;
use tm_photo_gallery\classes\Core;

/**
 * Gallery display
 */
class Display extends Structure {

	/**
	 * Display content
	 *
	 * @var type
	 */
	private $content;

	/**
	 * Contruct
	 *
	 * @param type $id
	 */
	public function __construct( $id ) {

		$prent_id = $this->get_gallery_id();

		if ( $prent_id ) {
			$id = $prent_id;
		}

		$this->content			 = Core::get_instance()->get_post_meta( $id, 'display' );
		$this->labels			 = $this->get_checkbox_val( 'labels' );
		$this->set_label		 = $this->get_set_label();
		$this->album_label		 = $this->get_album_label();
		$this->icon				 = $this->get_checkbox_val( 'icon' );
		$this->title			 = $this->get_checkbox_val('title');
		$this->description		 = $this->get_checkbox_val('description');
		$this->description_trim	 = $this->get_trim();
		$this->counter			 = $this->get_checkbox_val('counter');
	}

	/**
	 * Get label
	 *
	 * @return int
	 */
	private function get_checkbox_val( $checkbox ) {
		$show = 1;

		if ( isset( $this->content[$checkbox] ) ) {
			$show = (int) $this->content[$checkbox];
		}

		return $show;
	}

	/**
	 * Get set label
	 *
	 * @return int
	 */
	private function get_set_label() {
		if ( !empty( $this->content['set_label'] ) ) {
			$set_label = !empty( $this->content['set_label'] ) ? $this->content['set_label'] : __( 'Set', 'tm_gallery' );
		} else {
			$set_label = __( 'Set', 'tm_gallery' );
		}

		return $set_label;
	}

	/**
	 * Get albums label
	 *
	 * @return int
	 */
	private function get_album_label() {
		if ( !empty( $this->content['album_label'] ) ) {
			$album_label = !empty( $this->content['album_label'] ) ? $this->content['album_label'] : __( 'Album', 'tm_gallery' );
		} else {
			$album_label = __( 'Album', 'tm_gallery' );
		}

		return $album_label;
	}

	/**
	 * Get albums label
	 *
	 * @return int
	 */
	private function get_trim() {
		$trim = 10;

		if ( isset( $this->content['description_trim'] ) ) {
			$trim = (int) $this->content['description_trim'];
		}

		return $trim;
	}
}
