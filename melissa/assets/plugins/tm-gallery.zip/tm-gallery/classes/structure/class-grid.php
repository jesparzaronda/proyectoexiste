<?php
/**
 * Structure Gallery Grid
 *
 * @package classes/structure
 */

namespace tm_photo_gallery\classes\structure;

use tm_photo_gallery\classes\Structure;
use tm_photo_gallery\classes\Core;

/**
 * Gallery Grid
 */
class Grid extends Structure {

	/**
	 * Grid content
	 *
	 * @var type
	 */
	private $content;

	/**
	 * Grid pading
	 *
	 * @var type
	 */
	public $gutter;

	/**
	 * Colums
	 *
	 * @var type
	 */
	public $colums;

	/**
	 * Grid type
	 *
	 * @var type
	 */
	public $type;

	/**
	 * Construct
	 *
	 * @param type $id
	 */
	public function __construct( $id ) {

		$prent_id = $this->get_gallery_id();

		if ( $prent_id ) {
			$id = $prent_id;
		}

		$this->content	 = Core::get_instance()->get_post_meta( $id, 'grid' );
		$this->gutter	 = $this->get_gutter();
		$this->colums	 = $this->get_colums();
		$this->type		 = $this->get_type();
	}

	/**
	 * Get gutter
	 *
	 * @param type $id
	 * @return int
	 */
	private function get_gutter() {
		$gutter = 5;

		if ( isset( $this->content['gutter'] ) ) {
			$gutter = (int) $this->content['gutter'];
		}

		return $gutter;
	}

	/**
	 * Get colums
	 *
	 * @param type $id
	 * @return int
	 */
	private function get_colums() {
		return ! empty( $this->content['colums'] ) ? (int) ($this->content['colums']) : 3;
	}

	/**
	 * Get type
	 *
	 * @param type $id
	 * @return type
	 */
	private function get_type() {
		return ! empty( $this->content['type'] ) ? $this->content['type'] : 'grid';
	}
}
