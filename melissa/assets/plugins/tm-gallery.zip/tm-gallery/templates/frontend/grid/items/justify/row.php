<div class="tm-pg_front_gallery-justify_row">
	<?php do_action( 'tm-pg-grid-posts', $data['obj'], $data['posts'], true ); ?>
</div>
