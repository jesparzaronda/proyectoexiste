<div class="<?php echo apply_filters( 'tm-pg-swiper-container-class', 'swiper-container gallery-top' ) ?>">
	<div class="<?php echo apply_filters( 'tm-pg-swiper-wrapper-class', 'swiper-wrapper' ) ?>">
	</div>
	<!-- Add Arrows -->
	<div class="swiper-button-next swiper-button-white"></div>
	<div class="swiper-button-prev swiper-button-white"></div>
</div>
<div class="swiper-container gallery-thumbs">
	<div class="swiper-wrapper">
	</div>
	<!-- Add Arrows -->
	<div class="swiper-button-next swiper-button-white"></div>
	<div class="swiper-button-prev swiper-button-white"></div>
</div>
