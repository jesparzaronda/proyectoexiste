<div class="tm-pg_library-filter_selected-settings_cover" data-type="set_cover" style="display: none">
	<a href="#">
		<i class="material-icons">done</i>
	</a>
	<h5 class="tm-pg_library-filter_selected-title">
		<?php esc_attr_e( 'Set as cover', 'tm_gallery' ) ?>
	</h5>		
</div>
<div class="tm-pg_library-filter_selected-settings_cover" data-type="unset_cover" style="display: none">
	<a href="#">
		<i class="material-icons">close</i>
	</a>
	<h5 class="tm-pg_library-filter_selected-title">
		<?php esc_attr_e( 'Unset cover', 'tm_gallery' ) ?>
	</h5>		
</div>
