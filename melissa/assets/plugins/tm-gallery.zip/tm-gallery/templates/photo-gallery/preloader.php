<?php
/**
 * Preloader
 *
 * @package templates/photo-gallery
 */
?>
<div class="tm-pg_library_loading">
	<svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 66 66" height="60px" width="60px" class="preloader" style="display:inline-block">
		<use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#preloader"></use>
	</svg>
</div>
