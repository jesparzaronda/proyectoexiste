<?php
/**
 * Add new photo
 */
?>
<div class="tm-pg_column add-new">
	<div class="tm-pg_library_item_add" data-type="img">
		<a href="#" class="tm-pg_add-item tm-pg_add-photo">
			<i class="material-icons">add</i>
			<?php esc_attr_e( 'Add Photo', 'tm_gallery' ) ?>
		</a>
	</div>
</div>