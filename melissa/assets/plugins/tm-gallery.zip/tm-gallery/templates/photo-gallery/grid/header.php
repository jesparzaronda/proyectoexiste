<div class="tm-pg_library_grid_header">
	<div class="tm-pg_library_grid_header_content" > 
		<h5 class="tm-pg_library_title">
			<?php echo $data['title'] ?>	
		</h5>
		<div class="accordion-trigger">
			<a href="#" class="open" >
				<i  class="material-icons">keyboard_arrow_down</i>
			</a>
		</div>
	</div>
</div>
