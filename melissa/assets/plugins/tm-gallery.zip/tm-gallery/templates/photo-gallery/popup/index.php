<?php
/**
 * Popup
 *
 * @package templates/photo-gallery/popup
 */
?>
<div id="popup-wraper" style="display: none">
	<div class="tm-pg_library_popup">
		<div class="tm-pg_library_popup-title">
			<h5></h5>
			<a href="#"><i class="material-icons">clear</i></a>
		</div>
		<div class="tm-pg_library_popup-content" >

		</div>
	</div>
</div>
