<?php
/**
 * Popup item
 *
 * @package templates/photo-gallery/popup/models
 */
?>
<div id="popup-item">
	<div class="tm-pg_library_popup-item">
		<a class="tm-pg_library_popup-item_link" href="#">
			<figure>
				<div >
					<img src="#" class="hide" >
				</div>
				<figcaption>
				</figcaption>
			</figure>
		</a>
	</div>
</div>
