<div class="error">
	<p> <?php echo $message . esc_attr__( 'Plugin activation failed.', 'tm_gallery' ) ?></p>
</div>
