<div class="notice notice-warning">
	<p> <?php echo $message ?> </p>
</div>
