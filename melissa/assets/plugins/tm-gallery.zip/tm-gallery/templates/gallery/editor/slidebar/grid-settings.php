<?php
/**
 * Gallery editor grid-settings sledebar
 *
 * @package templates/gallery/slidebar
 */
?>
<div id="tm-pg-sidebar-scroll-container" class="tm-pg_sidebar_container">
	<h5 class="tm-pg_sidebar-title"><?php esc_attr_e( 'Properties', 'tm_gallery' ) ?></h5>
	<div class="tm-pg_hr"></div>
	<div id="sidebar-content">
		<div data-type="colums">
			<label for="colums">
				<span><?php esc_attr_e( 'Colums count', 'tm_gallery' ); ?> </span>
			</label>
			<select class="select2" data-placeholder="<?php esc_attr_e( 'Choose colum', 'tm_gallery' ) ?>" id="colums">
				<option value="2">2</option>
				<option value="3">3</option>
				<option value="4">4</option>
			</select>
		</div>
		<div class="tm-pg_spacer"></div>
		<div data-type="gutter">
			<p>
				<label for="gutter">
					<span><?php esc_attr_e( 'Gutter', 'tm_gallery' ); ?> </span>
				</label>
				<input type="number" name="gutter" min="0" max="50" id="gutter">
			</p>
		</div>
	</div>
</div>
