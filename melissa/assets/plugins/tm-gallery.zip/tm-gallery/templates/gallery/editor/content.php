<?php
/**
 * Gallery editor content
 *
 * @package templates\gallery\editor
 */
?>
<?php $this->render_html( 'gallery/editor/topbar/index' ); ?>

<div data-view="content">
	<div class="tm-pg_body-sidebar_container">
		<!-- /Filter -->
		<div class="tm-pg-scroll-cotainer">
			<div id="tm-pg-grid">
				<?php $this->render_html( 'photo-gallery/grid/sets', array( 'colums' => 3 ) ); ?>
				<?php $this->render_html( 'photo-gallery/grid/albums', array( 'colums' => 4 ) ); ?>
				<?php $this->render_html( 'photo-gallery/grid/photos', array( 'colums' => 6 ) ); ?>
			</div>
			<!-- Editor -->
			<div id="tm-pg-editor"></div>
		</div>
	</div>
	<?php $this->render_html( 'gallery/editor/slidebar/content' ); ?>
	<div class="clear"></div>
</div>
<div data-view="display" style="display: none">
	<div class="tm-pg_gallery_options_container">
		<?php $this->render_html( 'gallery/editor/display' ); ?>
	</div>
</div>
<div data-view="grid-settings" style="display: none">
	<div class="tm-pg_gallery_options_container tm-pg_gallery_options_container_grid_settings" >
		<?php $this->render_html( 'gallery/editor/grid-settings' ); ?>
	</div>
	<?php $this->render_html( 'gallery/editor/slidebar/grid-settings' ); ?>
</div>
<div data-view="animations" style="display: none">
	<div class="tm-pg_gallery_options_container">
		<?php $this->render_html( 'gallery/editor/animations' ); ?>
	</div>
</div>
<div data-view="navigation" style="display: none">
	<div class="tm-pg_gallery_options_container">
		<?php $this->render_html( 'gallery/editor/navigation' ); ?>
	</div>
</div>
<div data-view="pagination" style="display: none">
	<div class="tm-pg_gallery_options_container" >
		<?php $this->render_html( 'gallery/editor/pagination' ); ?>
	</div>
</div>
<div data-view="lightbox" style="display: none">
	<div class="tm-pg_gallery_options_container" >
		<?php $this->render_html( 'gallery/editor/lightbox' ); ?>
	</div>
</div>

