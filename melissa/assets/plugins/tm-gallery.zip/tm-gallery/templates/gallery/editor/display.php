<?php
/**
 * Gallery editor display
 *
 * @package templates/gallery/editor
 */
?>
<h6><?php esc_attr_e( 'Meta settings for Set / Albums', 'tm_gallery' ); ?></h6>
<div class="tm-pg_gallery_display">
	<div class="tm-pg_gallery_display_item" data-type="labels">
		<div class="ui tm-pg_ui tm-pg_checkbox">
			<div class="tm-pg_checkbox-item">
				<input type="checkbox" name="labels" id="show-labels">
				<label for="show-labels">
					<span class="checkbox"></span>
					<span class="name">	<?php esc_attr_e( 'Labels', 'tm_gallery' ); ?></span>
				</label>
			</div>
		</div>
	</div>
	<div class="tm-pg_gallery_display_item" data-type="set_label">
		<div class="ui tm-pg_ui tm-pg_text">
			<div class="tm-pg_text-item">
				<label for="set-label">
					<?php esc_attr_e( 'Set label', 'tm_gallery' ); ?> :
				</label>
				<input type="text" size="20" name="set_label" id="set-label">
			</div>
		</div>
	</div>
	<div class="tm-pg_gallery_display_item" data-type="album_label">
		<div class="ui tm-pg_ui tm-pg_text">
			<div class="tm-pg_text-item">
				<label for="albums-label">
					<?php esc_attr_e( 'Album label', 'tm_gallery' ); ?> :
				</label>
				<input type="text" size="20" name="album_label" id="albums-label">
			</div>
		</div>
	</div>
	<div class="tm-pg_gallery_display_item" data-type="icon">
		<div class="ui tm-pg_ui tm-pg_checkbox">
			<div class="tm-pg_checkbox-item">
				<input type="checkbox" name="icon" id="show-icon">
				<label for="show-icon">
					<span class="checkbox"></span>
					<span class="name">	<?php esc_attr_e( 'Icon', 'tm_gallery' ); ?></span>
				</label>
			</div>
		</div>
	</div>
	<div class="tm-pg_gallery_display_item" data-type="title">
		<div class="ui tm-pg_ui tm-pg_checkbox">
			<div class="tm-pg_checkbox-item">
				<input type="checkbox" name="title" id="show-title">
				<label for="show-title">
					<span class="checkbox"></span>
					<span class="name">	<?php esc_attr_e( 'Title', 'tm_gallery' ); ?></span>
				</label>
			</div>
		</div>
	</div>
	<div class="tm-pg_gallery_display_item" data-type="description">
		<div class="ui tm-pg_ui tm-pg_checkbox">
			<div class="tm-pg_checkbox-item">
				<input type="checkbox" name="description" id="show-description">
				<label for="show-description">
					<span class="checkbox"></span>
					<span class="name">	<?php esc_attr_e( 'Description', 'tm_gallery' ); ?></span>
				</label>
			</div>
		</div>
	</div>
	<div class="tm-pg_gallery_display_item" data-type="description_trim">
		<div class="ui tm-pg_ui tm-pg_number">
			<div class="tm-pg_number-item">
				<label for="show-description">
					<?php esc_attr_e( 'Description trim words', 'tm_gallery' ); ?>
				</label>
				<input type="number" name="description_trim" min="5" max="25" id="description-trim">
			</div>
		</div>
	</div>
	<div class="tm-pg_gallery_display_item" data-type="counter">
		<div class="ui tm-pg_ui tm-pg_checkbox">
			<div class="tm-pg_checkbox-item">
				<input type="checkbox" name="counter" id="show-counter">
				<label for="show-counter">
					<span class="checkbox"></span>
					<span class="name">	<?php esc_attr_e( 'Meta counter', 'tm_gallery' ); ?></span>
				</label>
			</div>
		</div>
	</div>
</div>
