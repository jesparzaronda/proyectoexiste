( function ( $ ) {
	"use strict";

	/*function galleryInit( galleryGrid ) {
		galleryGrid.lightGallery( {
			selector: 'div.gallery-item a',
			thumbnail: true,
			animateThumb: true,
			showThumbByDefault: true,
			toogleThumb: true,
			thumbContHeight: 80
		} );
		// Perform any action just before opening the gallery
		galleryGrid.on( 'onBeforeOpen.lg', function ( event ) {
			console.log( 'onBeforeOpen' );
			$( '#wpadminbar' ).css( 'z-index', '0' );
		} );
		galleryGrid.on( 'onCloseAfter.lg', function ( event ) {
			$( '#wpadminbar' ).css( 'z-index', '' );
		} )
	}

	galleryInit( $( '.tm-pg_front_gallery-grid' ) );*/
	/*galleryInit( $( '.tm-pg_front_gallery-masonry' ) );
	 galleryInit( $( '.tm-pg_front_gallery-justify' ) );*/

} )( jQuery );