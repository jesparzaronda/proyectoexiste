/*global _:false,Registry:false,jQuery:false, console:fale*/
Registry.register( "gl-editor-grid-settings", ( function ( $ ) {
	"use strict";
	var state;

	function __( value ) {
		return Registry._get( value );
	}

	/**
	 * Create instance
	 *
	 * @returns {grid-settings_L2.createInstance.grid-settingsAnonym$0}
	 */
	function createInstance() {
		return {
			_rightScrollContainer: '#tm-pg-sidebar-scroll-container',
			_item: '.tm-pg_gallery_grid-settings-type_item',
			_right: '#sidebar-content',
			/**
			 * Display content
			 */
			_content: { },
			/**
			 * Init grid-settings
			 *
			 * @returns {undefined}
			 */
			init: function ( ) {
				// refresh active
				$( state._item + ' a' ).removeClass( 'active' );
				__( 'gl-editor' ).hideSection();
				__( 'gl-editor' ).showSection( 'grid' );
				state.initRightScrollbar();
				// set content
				if ( _.isEmpty( state._content ) ) {
					state._content = $.extend( true, { }, __( 'gl-editor' )._gallery.grid );
				}
				// select current grid
				$( state._item + ' a.tm-pg_gallery_grid-settings-type_' + state._content.type ).addClass( 'active' );
				// init grid
				state.initGrid();
				// init right
				state.initRight();
			},
			/**
			 * Init grid
			 *
			 * @returns {undefined}
			 */
			initGrid: function ( ) {
				// On click grid settings grid item
				$( document ).on( 'click', state._item + ' a', state.onClickDisplayGrid.bind( this ) );
				//On change colums
				$( document ).on( 'change', state._right + ' div[data-type="colums"] select',
					state.onChangeColums.bind( this ) );
				//On change gutter
				$( document ).on( 'change', state._right + ' div[data-type="gutter"] input',
					state.onChangeGutter.bind( this ) );
			},
			/**
			 * On change colums
			 *
			 * @param {type} e
			 * @returns {undefined}
			 */
			onChangeColums: function ( e ) {
				state._content.colums = $( e.currentTarget ).val();
			},
			/**
			 * On change colums
			 *
			 * @param {type} e
			 * @returns {undefined}
			 */
			onChangeGutter: function ( e ) {
				state._content.gutter = $( e.currentTarget ).val();
			},
			/**
			 * On click grid settings grid item
			 *
			 * @param {Object} e - Mouse event.
			 */
			onClickDisplayGrid: function ( e ) {
				e.preventDefault();
				// refresh active
				$( state._item + ' a' ).removeClass( 'active' );
				// active current
				$( e.currentTarget ).addClass( 'active' );
				state._content.type = $( e.currentTarget ).data( 'type' );
				state.initRight();
			},
			/**
			 * Init right
			 *
			 * @param {type} type
			 * @returns {undefined}
			 */
			initRight: function ( ) {
				var colums = state._right + ' div[data-type="colums"]',
					gutter = state._right + ' div[data-type="gutter"]';

				$( colums + ' .select2' ).val( state._content.colums );
				// set colums
				if ( !_.isEqual( state._content.type, 'justify' ) ) {
					$( colums + ' .select2' ).select2( {
						minimumResultsForSearch: -1
					} );
					$( colums ).show();
				} else {
					$( colums ).hide();
				}

				$( gutter + ' input' ).val( state._content.gutter );
			},
			/**
			 * Init scrollbar
			 *
			 * @returns {undefined}
			 */
			initRightScrollbar: function () {
				// init sidebar scrollbar
				var rightHeight = innerHeight - $( state._rightScrollContainer ).offset().top - 30;
				$( state._rightScrollContainer ).height( rightHeight );
			}
		};
	}

	return {
		getInstance: function () {
			if ( !state ) {
				state = createInstance();
			}
			return state;
		}
	};
} )( jQuery ) );
