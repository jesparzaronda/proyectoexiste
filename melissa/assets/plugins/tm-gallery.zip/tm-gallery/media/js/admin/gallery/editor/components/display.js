/*global _:false,Registry:false,jQuery:false, console:fale*/
Registry.register( "gl-editor-display", ( function ( $ ) {
	"use strict";
	var state;

	function __( value ) {
		return Registry._get( value );
	}

	/**
	 * Create instance
	 *
	 * @returns {display_L2.createInstance.displayAnonym$0}
	 */
	function createInstance() {
		return {
			_item: '.tm-pg_gallery_display_item',
			/**
			 * Display content
			 */
			_content: { },
			/**
			 * Init display
			 *
			 * @returns {undefined}
			 */
			init: function ( ) {
				// refresh active
				$( state._item + ' a' ).removeClass( 'active' );
				__( 'gl-editor' ).hideSection();
				__( 'gl-editor' ).showSection( 'display' );
				// set content
				if ( _.isEmpty( state._content ) ) {
					state._content = $.extend( true, { }, __( 'gl-editor' )._gallery.display );
				}
				// init content
				state.initContent();
			},
			/**
			 * Init content
			 *
			 * @returns {undefined}
			 */
			initContent: function () {
				$( state._item + ' input:checkbox' ).each( function( ) {
					var $this = $( this ),
						name = $this.attr("name");

						if( state._content[name] )
							$this.prop( 'checked', true );
				} );
				$( state._item + ' input:text' ).each( function( ) {
					var $this = $( this ),
						name = $this.attr("name");

						if( state._content[name] )
							$this.val( state._content[name] );
				} );
				$( state._item + ' .tm-pg_number-item input' ).each( function( ) {
					var $this = $( this ),
						name = $this.attr("name");

						if( state._content[name] )
							$this.val( state._content[name] );
				} );
			},
			/**
			 * Init Event
			 *
			 * @returns {undefined}
			 */
			initEvents: function () {
				// on Change checkbox
				$( document ).on( 'change', state._item + ' input:checkbox', state.onChangeCheckbox.bind( this ) );
				// on Change text
				$( document ).on( 'change', state._item + ' input:text', state.onChangeText.bind( this ) );
				// on Change text
				$( document ).on( 'change', state._item + ' .tm-pg_number-item input', state.onChangeNumber.bind( this ) );
			},
			/**
			 * On change checkbox
			 *
			 * @param {type} e
			 * @returns {undefined}
			 */
			onChangeCheckbox: function ( e ) {
				var type = $( e.currentTarget ).parents( state._item ).data( 'type' );
				if ( $( e.currentTarget ).is( ":checked" ) ) {
					state._content[type] = 1;
				} else {
					state._content[type] = 0;
				}
			},
			/**
			 * On change text
			 *
			 * @param {type} e
			 * @returns {undefined}
			 */
			onChangeText: function ( e ) {
				var type = $( e.currentTarget ).parents( state._item ).data( 'type' );
				state._content[type] = e.target.value;
			},
			/**
			 * On change number
			 *
			 * @param {type} e
			 * @returns {undefined}
			 */
			onChangeNumber: function ( e ) {
				var type = $( e.currentTarget ).parents( state._item ).data( 'type' );
				state._content[type] = e.target.value;
			}
		};
	}

	return {
		getInstance: function () {
			if ( !state ) {
				state = createInstance();
			}
			return state;
		}
	};
} )( jQuery ) );
