<?php
return $language = array(
	'albums'                        => esc_attr__( 'Albums', 'tm_gallery' ),
	'sets'                          => esc_attr__( 'Sets', 'tm_gallery' ),
	'FILE_EXTENSION_ERROR'          => esc_attr__( 'The file %filename% could not be uploaded. File format not supported. Upload only JPG, PNG or GIF.', 'tm_gallery' ),
	'FILE_SIZE_ERROR'               => esc_attr__( 'The file %filename% exceeds the upload size limit (%size%).', 'tm_gallery' ),
	'error'                         => esc_attr__( 'Some error!', 'tm_gallery' ),
	'remove_cover'                  => esc_attr__( 'You just remove cover from the "%name%" %type%.', 'tm_gallery' ),
	'set_cover'                     => esc_attr__( 'You just set new cover for the "%name%" %type%.', 'tm_gallery' ),
	'upload_complite'               => esc_attr__( 'All photos uploaded successfully.', 'tm_gallery' ),
	'delete_all_dialog'             => esc_attr__(
		'Are you sure that you want delete all selected media ?',
		'tm_gallery'
	),
	'delete_all_fom_folder'         => esc_attr__(
		'Are you sure that you want remove all selected media from "%parent%"?',
		'tm_gallery'
	),
	'delete_set_dialog'             => esc_attr__( 'Are you sure that you want to delete "%name%" set ?', 'tm_gallery' ),
	'delete_album_dialog'           => esc_attr__(
		'Are you sure that you want to delete "%name%" album ?',
		'tm_gallery'
	),
	'delete_album_from_folder_dialog'           => esc_attr__(
		'Are you sure that you want to remove album "%name%" from "%parent%"?',
		'tm_gallery'
	),
	'delete_gallery_dialog'         => esc_attr__( 'Are you sure that you want to delete selected gallery ?', 'tm_gallery' ),
	'delete_img_dialog'             => esc_attr__( 'Are you sure that you want to delete "%name%" ?', 'tm_gallery' ),
	'delete_img_from_folder_dialog' => esc_attr__(
		'Are you sure that you want to remove "%name%" from "%parent%"?',
		'tm_gallery'
	),
	'all_deleted'				 => esc_attr__( 'You just permanently delete all selected media.', 'tm_gallery' ),
	'album_deleted'				 => esc_attr__( 'You just permanently delete "%name%" album.', 'tm_gallery' ),
	'set_deleted'				 => esc_attr__( 'You just permanently delete "%name%" set.', 'tm_gallery' ),
	'img_deleted'				 => esc_attr__( 'You just permanently delete "%name%".', 'tm_gallery' ),
	'added_to_set'				 => esc_attr__( 'You just add media to "%name%" set.', 'tm_gallery' ),
	'added_to_album'			 => esc_attr__( 'You just add media to "%name%" album.', 'tm_gallery' ),
	'allready_added_to_set'		 => esc_attr__( 'This media allready added to "%name%" set.', 'tm_gallery' ),
	'allready_added_to_album'	 => esc_attr__( 'This media allready added to "%name%" album.', 'tm_gallery' ),
	'delete_from_album'			 => esc_attr__( 'You just delete media from "%name%" album.', 'tm_gallery' ),
	'delete_from_set'			 => esc_attr__( 'You just delete media from "%name%" set.', 'tm_gallery' ),
	'add_tag'					 => esc_attr__( 'You just add "%name%" tag to media.', 'tm_gallery' ),
	'delete_tag'				 => esc_attr__( 'Are you sure that you want to delete tag ?', 'tm_gallery' ),
	'add_category'				 => esc_attr__( 'You just add "%name%" category to media.', 'tm_gallery' ),
	'delete_category'			 => esc_attr__( 'Are you sure that you want to delete category ?', 'tm_gallery' ),
	'remove_category'			 => esc_attr__( 'You just remove "%name%" category.', 'tm_gallery' ),
	'add_album'					 => esc_attr__( 'You just add "%name%" album.', 'tm_gallery' ),
	'add_set'					 => esc_attr__( 'You just add "%name%" set.', 'tm_gallery' ),
	'rotate'					 => esc_attr__( 'You just rotate image.', 'tm_gallery' ),
	'focus_point'				 => esc_attr__( 'You just set a focus point.', 'tm_gallery' ),
	'edit_post_title'			 => esc_attr__( 'You just change media title.', 'tm_gallery' ),
	'edit_post_content'			 => esc_attr__( 'You just change media description.', 'tm_gallery' ),
	'add_gallery'				 => esc_attr__( 'You just add "%name%" gallery.', 'tm_gallery' ),
	'edit_gallery'				 => esc_attr__( 'You just change gallery name.', 'tm_gallery' ),
	'delete_gallery'			 => esc_attr__( 'You just delete selected gallery.', 'tm_gallery' ),
	'public_gallery'			 => esc_attr__( 'You just restore selected gallery.', 'tm_gallery' ),
	'trash_gallery'				 => esc_attr__( 'You just add to trash selected gallery.', 'tm_gallery' ),
	'save_gallery'				 => esc_attr__( 'You just save "%name%" gallery.', 'tm_gallery' ),
	'add_photo_gallery'			 => esc_attr__( 'Add TM photo gallery', 'tm_gallery' ),
);
